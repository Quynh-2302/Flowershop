<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2020 Brought To You By<a href="https://itsourcecode.com/">IT SOURCE CODE</a></strong>
</footer>